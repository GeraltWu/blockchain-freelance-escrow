import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 61130,
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:61131',
        changeOrigin: true,
      },
    },
  },
})
